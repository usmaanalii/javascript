export function addTax(amount, taxRate) {
  return amount + (amount * taxRate);
}
